#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 12 13:31:36 2019

@author: yiwenzhang
"""
from collections import Counter

def replace_rare(input_file='ner_train.dat', output_file='ner_train_rare.dat', benchmark=5): 
	count = Counter([line.split()[0] for line in open(input_file,'r') if line.strip()!='']) 
	open(output_file,'w+').write('\n'.join([ line.strip() if line.strip()=='' or count[line.split()[0]]>=benchmark else '_RARE_ '+line.split()[1] for line in open(input_file,'r') ])) 
    
if __name__ == "__main__":
    replace_rare()