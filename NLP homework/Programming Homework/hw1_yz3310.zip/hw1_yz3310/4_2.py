#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 12 15:55:02 2019

@author: yiwenzhang
"""
import os
from collections import defaultdict
from math import log

def remove_ner_tag(key='ner_dev.key', dat='ner_dev.dat'): 
	open(dat,'w+').write('\n'.join([line.split()[0] if line.strip()!='' else '' for line in open(key,'r')]))

def cal_emission_prob(input_file='ner_rare.counts'):
	raw = [line.split() for line in open(input_file,'r')] 
	counts = defaultdict(int)
	for e in [ (int(a[0]), a[2], a[3]) for a in raw if a[1]=='WORDTAG' ] :
		counts[e[1]] += e[0] 
	emission_parameter = defaultdict(lambda:defaultdict(lambda:-float('inf'))) 
	for e in [ (int(a[0]), a[2], a[3]) for a in raw if a[1]=='WORDTAG' ] :
		emission_parameter[e[2]].update({ e[1]: log(float(e[0]))-log(float(counts[e[1]])) }) 
	return emission_parameter

def baseline(input_file='ner_dev.dat', output_file='out'): 
	emission_parameter = cal_emission_prob() 
	open(output_file,'w+').write( '\n'.join([ '{} {} {}'.format(line.strip(), *max(emission_parameter[line.strip() if line.strip() in emission_parameter else '_RARE_'].items(), key=lambda e: e[1])) if line.strip()!='' else '' for line in open(input_file,'r') ] + ['\n']*2 ) ) 
		

if __name__ == '__main__':
	os.system('python2.7 count_freqs.py ner_train_rare.dat> ner_rare.counts')
	remove_ner_tag() 
	baseline(output_file='4_2.txt') 

