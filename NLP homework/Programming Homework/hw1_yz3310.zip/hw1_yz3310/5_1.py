#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 00:07:55 2019

@author: yiwenzhang
"""

from math import log
import os
def calculate_transition_prob(input_file = "ner_rare.counts"):
    split = []
    transition_prob = {}
    with open(input_file, "r") as input:
        for line in input.readlines():
            split.append(line.split())
    bigram = {(line[2], line[3]) : float(line[0]) for line in split if line[1] == "2-GRAM"}
    trigram = {(line[2], line[3], line[4]) : float(line[0]) for line in split if line[1] == "3-GRAM"}
    for k, v in trigram.items():
        transition_prob[k] = log(v/(bigram[(k[0], k[1])]))
    return transition_prob


if __name__ == "__main__":
    os.system("python2.7 count_freqs.py ner_train_rare.dat > ner_rare.counts")
    transition_prob = calculate_transition_prob()
    with open("trigrams.txt", "r") as input, open("5_1.txt", "w") as output:
        for line in input.readlines():
            if line.strip():
                words = line.strip().split()
                output.write("{} {} {} {}\n".format(words[0], words[1], words[2],transition_prob[(words[0], words[1], words[2])]))