#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 00:30:06 2019

@author: yiwenzhang
"""
from math import log
from collections import defaultdict



def calculate_transition_prob(input_file = "ner_rare.counts"):
    split = []
    transition_prob = {}
    with open(input_file, "r") as input:
        for line in input.readlines():
            split.append(line.split())
    bigram = {(line[2], line[3]) : float(line[0]) for line in split if line[1] == "2-GRAM"}
    trigram = {(line[2], line[3], line[4]) : float(line[0]) for line in split if line[1] == "3-GRAM"}
    for k, v in trigram.items():
        transition_prob[k] = log(v/(bigram[(k[0], k[1])]))
    return transition_prob


def cal_emission_prob(input_file='ner_rare.counts'):
	raw = [line.split() for line in open(input_file,'r')] 
	counts = defaultdict(int)
	for e in [ (int(a[0]), a[2], a[3]) for a in raw if a[1]=='WORDTAG' ] :
		counts[e[1]] += e[0] 
	emission_parameter = defaultdict(lambda:defaultdict(lambda:-float('inf'))) 
	for e in [ (int(a[0]), a[2], a[3]) for a in raw if a[1]=='WORDTAG' ] :
		emission_parameter[e[2]].update({ e[1]: log(float(e[0]))-log(float(counts[e[1]])) }) 
	return emission_parameter

def tags(intput_file = "ner_rare.counts"):
    tags = {line.split(" ")[2] for line in open(intput_file, 'r') if line.strip() and line.split(" ")[1] == "WORDTAG"}
    return tags

def viterbi(x):
    def get_tag(i):
        return tags if i >= 0 else {"*"}

    pi = defaultdict(lambda: float("-inf"))
    pi[(-1, "*", "*")] = 0
    bp = defaultdict(str)
    for i in range(len(x)):
        for u in get_tag(i - 1):
            for v in get_tag(i):
                max_value = float("-inf")
                arg_max = ""
                for w in get_tag(i - 2):
                    if emission[x[i]][v] != 0 and (w,u,v) in trainsition:
                        new_value = pi[(i - 1, w, u)] + trainsition[(w, u, v)] + emission[x[i]][v]
                        if new_value > max_value:
                            max_value = new_value
                            arg_max = w
                pi[(i, u, v)] = max_value
                bp[(i, u, v)] = arg_max

    u_value = v_value = ""
    max_value = float("-inf")
    for u in get_tag(len(x) - 2):
        for v in get_tag(len(x) - 1):
            if (u, v, "STOP") in trainsition:
                new_value = pi[(len(x) - 1, u, v)] + trainsition[(u, v, "STOP")]
                if new_value > max_value:
                    max_value = new_value
                    u_value = u
                    v_value = v

    result = [''] * len(x)
    result[-1] = v_value
    if len(x) >= 2:
        result[-2] = u_value

    for k in range(len(x) - 3, -1, -1):
        result[k] = bp[(k + 2, result[k+1], result[k+2])]

    return result, [pi[(k, result[k-1], result[k])] if k >= 1 else pi[(0, "*", result[k])] for k in range(len(x))]

def get_count(input_file = "ner_train_rare.dat"):
    count = defaultdict(int)
    with open(input_file,'r') as input:
        for line in input.read().split('\n'):
            if line.strip():
                word = " ".join(line.strip().split(" ")[:-1])
                count[word] += 1
    return count

def tagger(input_file = "ner_dev.dat", output_file = "5_2.txt"):
    sentences = []
    with open(input_file, "r") as input:
        raw_words = []
        for line in input:
            word = line.strip()
            if not word:
                sentences.append(raw_words)
                raw_words = []
            else:
                raw_words.append(word)
        if len(raw_words) != 0:
            sentences.append(raw_words)

    count = get_count()
    ls = []
    for s in sentences:
        x = []
        for word in s:
            word_rare = "_RARE_" if word not in count else word
            x.append(word_rare)
        tags, prob = viterbi(x)
        for i in range(len(x)):
            ls.append(" ".join([s[i], tags[i], str(prob[i])]))
        ls.append("")

    with open(output_file, "w") as output:
        output.write("\n".join(ls))
        output.write("\n")

if __name__ == "__main__":
    tags = tags()
    emission = cal_emission_prob()
    trainsition = calculate_transition_prob()    
    tagger()
