#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 15:35:42 2019

@author: yiwenzhang
"""

import json
import os
from collections import defaultdict

class rm(object):
    benchmark = 5
    def __init__(self, input_file, output_file):
        self.input_file = input_file
        self.output_file = output_file
        self.counter = defaultdict(int)

    def getCount(self):
        os.system("python count_cfg_freq.py " + self.input_file + " > cfg.counts")
        for l in open("cfg.counts", 'r'):
            lines = l.strip().split(" ")
            if lines[1] == "UNARYRULE":
                self.counter[lines[3]] += int(lines[0])

    def replace(self): 
        cache = []
        for l in open(self.input_file):
            tree = json.loads(l)
            self.recurssive(tree)
            line = json.dumps(tree)
            cache.append(line)
        with open(self.output_file, 'w') as output:
            output.write("\n".join(cache))

    def recurssive(self, tree):
        if len(tree) == 2 and self.counter[tree[1]] < rm.benchmark:
                tree[1] = "_RARE_"
        elif len(tree) == 3:
            self.recurssive(tree[1])
            self.recurssive(tree[2])