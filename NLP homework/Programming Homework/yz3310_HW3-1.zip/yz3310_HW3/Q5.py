#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 16:06:49 2019

@author: yiwenzhang
"""
from collections import defaultdict
import os
from math import log
import json


class CKY(object):

    countfile= "cfg.rare.counts"
    def __init__(self, input_train_file, input_dev_file, output_file):
        self.input_train_file = input_train_file
        self.input_dev_file = input_dev_file
        self.output_file = output_file
        self.terminal = set()
        self.nonterminal = defaultdict(int)
        self.unary = defaultdict(int)
        self.binary = defaultdict(int)
        self.q_unary= defaultdict(lambda: float("-inf"))
        self.q_binary = defaultdict(lambda: defaultdict(lambda: float("-inf")))

    def parameters(self):
        os.system("python count_cfg_freq.py %s > %s" % (self.input_train_file, CKY.countfile))

        for l in open(CKY.countfile, "r"):
            words = l.strip().split(" ")
            if words[1] == "NONTERMINAL":
                self.nonterminal[words[2]] += int(words[0])
            elif words[1] == "BINARYRULE":
                self.binary[tuple(words[-3:])] += int(words[0])
            elif words[1] == "UNARYRULE":
                self.unary[tuple(words[-2:])] += int(words[0])
                self.terminal.add(words[3])

        for k, v in self.binary.items():
            self.q_binary[k[0]][(k[1], k[2])] = log(float(v)) - log(float(self.nonterminal[k[0]]))
        for k, v in self.unary.items():
            self.q_unary[k] = log(float(v)) - log(float(self.nonterminal[k[0]]))



    def out(self):

        def gen_data():
            for l in open(self.input_dev_file):
                rr = []
                words = l.strip().split(" ")
                for word in words:
                    if word not in self.terminal:
                        rr.append("_RARE_")
                    else:
                        rr.append(word)
                yield rr, words


        def tree_builder(a, hi, bp, X, ori):
            if a != hi:
                rules, s = bp[(a, hi, X)]
                return [X, tree_builder(a, s, bp, rules[0], ori),
                        tree_builder(s + 1, hi, bp, rules[1], ori)]
            else:
                return [X, ori[a]]

        out = []
        for x, ori in gen_data():
            n = len(x)
            pi = defaultdict(lambda: float("-inf"))
            bp = defaultdict(tuple)
            for i in range(n):
                for X in self.nonterminal:
                    if (X, x[i]) in self.q_unary:
                        pi[(i, i, X)] = self.q_unary[(X, x[i])]

            for l in range(1, n):
                for i in range(n - l):
                    j = i + l
                    for X in self.nonterminal:
                        prob_t = float("-inf")
                        rule_t = ()
                        s_t = 0
                        for rule in self.q_binary[X]:
                            Y = rule[0]
                            Z = rule[1]
                            for s in range(i, j):
                                prob = self.q_binary[X][rule] + pi[(i, s, Y)] + pi[(s + 1, j, Z)]
                                if prob > prob_t:
                                    prob_t = prob
                                    rule_t = rule
                                    s_t = s
                        pi[(i, j, X)] = prob_t
                        bp[(i, j, X)] = (rule_t, s_t)

            if pi[(0, n - 1, "S")] != -float("inf"):
                tree = tree_builder(0, n - 1, bp, "S", ori)
                out.append(json.dumps(tree))
            else:
                X_t = ""
                prob_t = -float("inf")
                for X in self.nonterminal:
                    if pi[(0, n - 1, X)] > prob_t:
                        X_t = X
                        prob_t = pi[(0, n - 1, X)]
                tree = tree_builder(0, n-1, bp, X_t, ori)
                out.append(json.dumps(tree))

        with open(self.output_file, "w") as output:
            output.write("\n".join(out))

