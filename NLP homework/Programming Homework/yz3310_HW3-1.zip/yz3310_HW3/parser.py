#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 15:43:46 2019

@author: yiwenzhang
"""

import sys
import Q4
import Q5


if __name__ == "__main__":         
    if sys.argv[1] == "q4":  
        rare_maker = Q4.rm(sys.argv[2], sys.argv[3])
        rare_maker.getCount()
        rare_maker.replace()

    elif sys.argv[1] == "q5" or sys.argv[1] == "q6":
        cky = Q5.CKY(sys.argv[2], sys.argv[3], sys.argv[4])
        cky.parameters()
        cky.out()      



