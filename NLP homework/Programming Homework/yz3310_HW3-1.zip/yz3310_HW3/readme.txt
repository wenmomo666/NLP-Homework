{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf200
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fswiss\fcharset0 ArialMT;\f2\froman\fcharset0 TimesNewRomanPSMT;
\f3\fnil\fcharset134 PingFangSC-Regular;\f4\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\ri0\partightenfactor0

\f0\fs24 \cf0 Yiwen Zhang\

\f1 yz3310\
HW3 Programming\
\
\'97Folder Structure
\f0 \

\f1 \uc0\u9500 \u9472 \u9472  cfg.counts 	# temporary file\
\uc0\u9500 \u9472 \u9472  cfg.rare.counts 	# temporary file\
\uc0\u9500 \u9472 \u9472  count_cfg_freq.py 	# given file\
\uc0\u9500 \u9472 \u9472  eval_parser.py 	# given file\
\uc0\u9500 \u9472 \u9472  parse_dev.dat 	# given file\
\uc0\u9500 \u9472 \u9472  parse_dev.key 	# given file\
\uc0\u9500 \u9472 \u9472  parser.py 	# required file\
\uc0\u9500 \u9472 \u9472  parse_train.dat 	# given file\
\uc0\u9500 \u9472 \u9472  parse_train.RARE.dat 	# required file\
\uc0\u9500 \u9472 \u9472  parse_train_vert.dat 	# given file\
\uc0\u9500 \u9472 \u9472  parse_train_vert.RARE.dat 	# required file\
\uc0\u9500 \u9472 \u9472  pretty_print_tree.py 	# given file\
\uc0\u9500 \u9472 \u9472  Q4.py # core code for Question 4\'a0\'a0\'a0\
\uc0\u9500 \u9472 \u9472  Q5.py # core code for Question 5 and Question 6\'a0 \
\uc0\u9500 \u9472 \u9472  q5_eval.txt 	# required file\
\uc0\u9500 \u9472 \u9472  q5_prediction_file 	# required file\
\uc0\u9500 \u9472 \u9472  q6_eval.txt 	# required file\
\uc0\u9500 \u9472 \u9472  q6_prediction_file 	# required file\
\uc0\u9492 \u9472 \u9472  Readme.txt 	# required file
\f2 \

\f0 \

\f1 Q4 takes 
\f3 less than 
\f1 1seconds
\f3 , 
\f1 Q5 takes ~40 seconds, and Q6 takes ~70 seconds.\
\
Question 5
\f3 :\
Performance:\
*****************************************************************************\

\f4 Type       Total       Precision     Recall   F1 Score\
===============================================================\
.          370               1.0        1.0        1.0\
ADJ        164             0.827      0.555      0.664\
ADJP       29              0.333      0.241       0.28\
ADJP+ADJ   22              0.542      0.591      0.565\
ADP        204             0.955      0.946      0.951\
ADV        64              0.694      0.531      0.602\
ADVP       30              0.333      0.133       0.19\
ADVP+ADV   53              0.756      0.642      0.694\
CONJ       53                1.0        1.0        1.0\
DET        167             0.988      0.976      0.982\
NOUN       671             0.752      0.842      0.795\
NP         884             0.623      0.523      0.569\
NP+ADJ     2               0.286        1.0      0.444\
NP+DET     21              0.783      0.857      0.818\
NP+NOUN    131             0.641      0.573      0.605\
NP+NUM     13              0.214      0.231      0.222\
NP+PRON    50               0.98       0.98       0.98\
NP+QP      11              0.667      0.182      0.286\
NUM        93              0.984      0.645      0.779\
PP         208             0.588      0.625      0.606\
PRON       14                1.0      0.929      0.963\
PRT        45              0.957      0.978      0.967\
PRT+PRT    2                 0.4        1.0      0.571\
QP         26              0.647      0.423      0.512\
S          587             0.629      0.785      0.698\
SBAR       25             0.0909       0.04     0.0556\
VERB       283             0.683      0.799      0.736\
VP         399             0.559      0.594      0.576\
VP+VERB    15               0.25      0.267      0.258\
\
\
total      4664            0.713      0.713      0.713\
****************************************************************\
\
Observations:\
1. Function words, such as CONJ,DET, PRON, PRT, ADP, and . have higher F1-scores than content words, because function words are have very high frequency and only a few words are function words, which lead to a very low ambiguity. \
2. SBAR, ADVP, ADJP have low score, because they have dependency on words that kind of far away from them.\
3. Rare words got relatively low score. We could know the sparsity bring some issue but rare counts would mitigate it.\
\
\
Question6:\
Performance:\
****************************************************************\
Type       Total       Precision     Recall   F1 Score\
===============================================================\
.          370               1.0        1.0        1.0\
ADJ        164             0.689      0.622      0.654\
ADJP       29              0.324      0.414      0.364\
ADJP+ADJ   22              0.591      0.591      0.591\
ADP        204              0.96      0.951      0.956\
ADV        64              0.759      0.641      0.695\
ADVP       30              0.417      0.167      0.238\
ADVP+ADV   53                0.7       0.66       0.68\
CONJ       53                1.0        1.0        1.0\
DET        167             0.988      0.994      0.991\
NOUN       671             0.795      0.845      0.819\
NP         884             0.617      0.548       0.58\
NP+ADJ     2               0.333        0.5        0.4\
NP+DET     21              0.944       0.81      0.872\
NP+NOUN    131              0.61      0.656      0.632\
NP+NUM     13              0.375      0.231      0.286\
NP+PRON    50               0.98       0.98       0.98\
NP+QP      11               0.75      0.273        0.4\
NUM        93              0.914      0.688      0.785\
PP         208             0.623      0.635      0.629\
PRON       14                1.0      0.929      0.963\
PRT        45                1.0      0.933      0.966\
PRT+PRT    2               0.286        1.0      0.444\
QP         26               0.65        0.5      0.565\
S          587             0.704      0.814      0.755\
SBAR       25              0.667        0.4        0.5\
VERB       283              0.79      0.813      0.801\
VP         399             0.663      0.677       0.67\
VP+VERB    15              0.294      0.333      0.312\
\
\
total      4664            0.742      0.742      0.742\
****************************************************************\
\
Observations:\
1. Thanks to vertical markovization, total F1-score is higher than question5 and performance of SBAR also improved. Therefore, we could see vertical markovization fit better here.\
2. SBAR got higher score here than q5, which thanks to vertical markovization consider more contextual information and long-distance dependency.\
3. 'ADVP+ADV', 'NP+ADJ' have lower score than question5. This is because vertical markovization greatly increases the number of rules N in the grammar potentially causing data sparsity issues, which reduces the accuracy of parameter estimation.\
\
}